﻿namespace Models.Enumerations
{
    public enum Specialty
    {
        SuperMan = 1,
        Batman = 1 << 1,
        BatmanOtYambol = 1 << 2,
        Robot = 1 << 3
    }
}