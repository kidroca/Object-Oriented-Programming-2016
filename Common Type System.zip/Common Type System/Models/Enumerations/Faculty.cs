﻿namespace Models.Enumerations
{
    public enum Faculty
    {
        SelfHealing = 1,
        Lasers = 2,
        MindManipulation = 3,
        Telekinesis
    }
}