﻿namespace Models.Enumerations
{
    public enum University
    {
        XavierInstitute = 1,
        NormalUniversity = 2,
        SchoolOfRock = 3,
        LegionAcademy = 4
    }
}