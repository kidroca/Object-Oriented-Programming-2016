# Homework information

## Build

* First build the project so required packages fetched from Nuget.org
* In Visual Studio the Build shortcut is `Ctrl + Shfit + B`

# Assing the startup project as current selection

* Click the solution with the second mouse button and select properties
* Select the `Current Selection` radio button