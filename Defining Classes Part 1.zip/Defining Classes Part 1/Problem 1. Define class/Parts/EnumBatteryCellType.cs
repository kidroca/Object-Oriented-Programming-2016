﻿namespace MobileDevices.Parts
{
    public enum BatteryCellType
    {
        LiIon,
        NiMH,
        NiCd,
        LiIonPolymer,
        Experimental
    }
}
